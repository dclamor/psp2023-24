#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>
#define MD5_LEN 16

void comprobar(char** passwords, char* result)
{

                    if(strcmp(result,passwords[1])==0)
                    {
                        printf("%s = %s",passwords[1],result);
                    }
                    else if(strcmp(result,passwords[2])==0)
                    {
                        printf("%s = %s",passwords[2],result);
                    }
                    else if(strcmp(result,passwords[3])==0)
                    {
                        printf("%s = %s",passwords[3],result);
                    }
                    else if(strcmp(result,passwords[0])==0)
                    {
                        printf("%s = %s",passwords[0],result);
                    }                 
                    

}

void magia(const char *string, unsigned char *str_result) {
    EVP_MD_CTX *ctx;
    const EVP_MD *md;
    unsigned char result[EVP_MAX_MD_SIZE];

    ctx = EVP_MD_CTX_new();
    md = EVP_md5();

    EVP_DigestInit_ex(ctx, md, NULL);
    EVP_DigestUpdate(ctx, string, strlen(string));
    EVP_DigestFinal_ex(ctx, result, NULL);

    EVP_MD_CTX_free(ctx);

    for(int i = 0; i < MD5_LEN; i++){   // MD5 result is always 16 bytes
        sprintf(str_result+(i*2),"%02x", result[i]);
    }
    
}


int main(int arc, char *argv[])
{
    char *string = argv[1];

    unsigned char result[EVP_MAX_MD_SIZE];
    unsigned int result_len;

    magia(string, result);
    char prueba[] = "aaaa";
    char password1[] = "582fc884d6299814fbd4f12c1f9ae70f";
    char password2[] = "74437fabd7c8e8fd178ae89acbe446f2";
    char password3[] = "28ea19352381b8659df830dd6d5c90a3";
    char password4[] = "90f077d7759d0d4d21e6867727d4b2bd";
    char* passwords[] = {password1,password2,password3,password4};
    for (int i = 0; i < 26; i++)
    {
        for (int j = 0; i < 26; j++)
        {
            for (int k = 0; i < 26; k++)
            {
                for (int l = 0; i < 26; l++)
                {    
                    magia(prueba, result);  
                    comprobar(result,passwords);                  
                    
                    if(prueba[3]=='z'){
                        prueba[3]='a';
                    }else{
                        prueba[3] = (char)prueba[3] + 1;
                    }
                    
                }
                magia(prueba, result);
                comprobar(result,passwords);  
                 if(prueba[2]=='z'){
                        prueba[2]='a';
                    }else{
                        prueba[2] = (char)prueba[3] + 1;
                    }

               
            }
            magia(prueba, result);
            comprobar(result,passwords);  
             if(prueba[1]=='z'){
                        prueba[1]='a';
                    }else{
                        prueba[1] = (char)prueba[3] + 1;
                    }
            
        }
        magia(prueba, result);
        comprobar(result,passwords);  
        prueba[0] = (char)prueba[0] + 1;
        
    }

    printf("MD5(\"%s\") = %s", string, result);

    printf("\n");

    return 0;
}
