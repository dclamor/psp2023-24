#include <stdio.h>
//Funcion que incrementa recibe un puntero
void incRef(int *h)
{
    //asterisco hace referenca al contenido del puntero
    (*h)++;
}
void incVal(int h)
{
    h++;
}


int main(void){
    int n =42;
    int *pn;
    pn = &n;
    fprintf(stdout,"Valor %d y puntero %X\n", n,pn);
    fprintf(stdout,"Valor %d y puntero %X\n", *pn,&n);
    incRef(&n);
    incVal(n);
    fprintf(stdout,"¿Qué imprime? %d\n", n);
}