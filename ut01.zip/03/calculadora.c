#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {    
    if (argc < 4) {
        printf("Uso: %s <operación> <operando1> <operando2>\n", argv[0]);
        return 1;
    }

    char *operacion = argv[1];
    float operando1 = atof(argv[2]);
    float operando2 = atof(argv[3]);

    
    if (strcmp(operacion, "suma") == 0) {
        printf("Resultado: %.2f\n", operando1 + operando2);
    } else if (strcmp(operacion, "resta") == 0) {
        printf("Resultado: %.2f\n", operando1 - operando2);
    } else if (strcmp(operacion, "multiplicacion") == 0) {
        printf("Resultado: %.2f\n", operando1 * operando2);
    } else if (strcmp(operacion, "division") == 0) {
        
        if (operando2 == 0) {
            printf("Error: No se puede dividir por cero.\n");
        } else {
            printf("Resultado: %.2f\n", operando1 / operando2);
        }
    } else {
        printf("Operación no válida. Las operaciones válidas son: suma, resta, multiplicacion, division\n");
    }

    return 0;