#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>

void magia(const char *string, unsigned char *str_result) {
    EVP_MD_CTX *ctx;
    const EVP_MD *md;
    unsigned char result[EVP_MAX_MD_SIZE];

    ctx = EVP_MD_CTX_new();
    md = EVP_md5();

    EVP_DigestInit_ex(ctx, md, NULL);
    EVP_DigestUpdate(ctx, string, strlen(string));
    EVP_DigestFinal_ex(ctx, result, NULL);

    EVP_MD_CTX_free(ctx);

    for(int i = 0; i < EVP_MD_size(md); i++) {
        sprintf((char *)str_result+(i*2), "%02x", result[i]);
    }
}

int main() {
    char prueba[] = "aaaa";
    char *passwords[] = {
        "582fc884d6299814fbd4f12c1f9ae70f",
        "74437fabd7c8e8fd178ae89acbe446f2",
        "28ea19352381b8659df830dd6d5c90a3",
        "90f077d7759d0d4d21e6867727d4b2bd"
    };
    int coincidencias = 0;

    while (prueba[0] <= 'z' && coincidencias < 4) {
        unsigned char result[EVP_MAX_MD_SIZE];
        magia(prueba, result);
        char hash_str[33];
        sprintf(hash_str, "%s", result);
        
        printf("Probando combinación: %s - Hash: %s\n", prueba, hash_str);
        
        if(strcmp(hash_str, passwords[0]) == 0 || 
           strcmp(hash_str, passwords[1]) == 0 ||
           strcmp(hash_str, passwords[2]) == 0 ||
           strcmp(hash_str, passwords[3]) == 0) {
            printf("Contraseña encontrada: %s\n", prueba);
            coincidencias++;
        }

        // Incrementa la cadena de prueba para la siguiente iteración
        for (int i = 3; i >= 0; i--) {
            if (prueba[i] == 'z') {
                prueba[i] = 'a';
            } else {
                prueba[i]++;
                break;
            }
        }
    }

    if (coincidencias == 0) {
        printf("No se encontraron coincidencias.\n");
    }

    return 0;
}
