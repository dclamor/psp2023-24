#include <stdio.h>

int main (void){
    int num = 42;
    int suma;
    printf("Introduce un número \n");
    scanf("%d",&num);
    suma=num;
    printf("introduce el siguiente \n");
    scanf("%d",&num);
    suma+=num;
    printf("La suma es %d\n",&suma);
    return 0 ; //siempre bien!
}