#include <stdio.h>
#include<string.h>
#include<stdbool.h>
 int main(void){

    char cadenaUsuario[h];

    fgets(cadenaUsuario,sizeof(cadenaUsuario),stdin);
    bool palindromo=false;
    for (int i =0;i<strlen(cadenaUsuario)/2;i++){
        if (cadenaUsuario[i]=cadenaUsuario[strlen(cadenaUsuario)-i])
        
        palindromo=true;        
    }
    if (palindromo)
    printf("%s es un palíndromo",cadenaUsuario);
    else
    printf("%s no es un palíndromo");

 }