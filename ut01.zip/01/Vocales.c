#include <stdio.h>
#include <string.h>
#define BUFFER 1024

int main (void){

    char cadenaUsuario[BUFFER];
    char cadenaVocales[11]={'A','E','I','O','U','a','e','i','o','u'};
    int nVocales=0;
    printf("Introduce una cadena de caracteres");
    fgets(cadenaUsuario,sizeof(cadenaUsuario),stdin);
    for (int i=0;i<=strlen(cadenaVocales)-1;i++)
    {
        for (int j=0; j<=strlen(cadenaUsuario)-1;j++)
        {
            if (cadenaUsuario[j]==cadenaVocales[i])
            nVocales++;
        }
        
    }
     printf("El número de vocales de la cadena es:  %d\n",nVocales);
     return 0;


}