#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int esPrimo(int n)
{
    int primo =1;
    int i = 2;
    while (primo && i<n/2)
    {
        if(n%i==0){
            primo =0;
        }
        i++;
                
    }
    return primo;
    
}

int main (void){
    pid_t id_hijo;

     unsigned int n = 312524867;
    
    //clonación
    id_hijo=fork();
    //ahora hay 2 procesos
    if(id_hijo !=0){
//padre
    int status=0;
    wait(&status);
    fprinf(stdout,"El hijo ha finalizado %d/n",WEXITSTATUS(status));
    return 0;
    }else{
//hijo
    int primo = esPrimo(n);
    exit(primo);

    }

    return 0;    
}