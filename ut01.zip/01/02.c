#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main (void){
    pid_t id_hijo;

     unsigned int n = 31;
    double pi =3.14;
    //clonación
    id_hijo=fork();
    //ahora hay 2 procesos
    if(id_hijo !=0){
        printf("Soy el padre mi id es %d, y mi hijo es %d\n", getpid(),id_hijo);

    }else{
        printf("Soy el hijo mi id es %d el de mi padre es %d\n",getpid(),getppid());

    }

    return 0;    
}