#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void signusr1_handler(int signal)
{
   
      printf("Hola\n");    
    
}
void signusr2_handler(int signal)
{
   
      printf("Mundo\n");        
    
}   



int main(int argc, char *argv[])
{

    signal(SIGUSR1, signusr1_handler);
    signal(SIGUSR2, signusr2_handler);

    while (1)
    {
        sleep(1);
    }
    return 0;
}
