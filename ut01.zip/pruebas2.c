#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>
#include <unistd.h>
#include <sys/wait.h>

void calcularMD5(const char *cadena, unsigned char *resultado) {
    // Función para calcular el hash MD5, igual que antes
    // ...
}

int main() {
    char cadena[] = "aaaa";
    unsigned char resultado[EVP_MAX_MD_SIZE];
    char contrasenas[500][5];  // Almacena hasta 500 contraseñas de 4 caracteres + null terminator
    int contador = 0;

    pid_t pid = fork();

    if (pid == -1) {
        // Error al crear el proceso hijo
        perror("Error al crear el proceso hijo");
        return 1;
    }

    if (pid == 0) {
        // Proceso hijo: generando combinaciones de "aaaa" a "zzz"
        while (cadena[0] <= 'z') {
            calcularMD5(cadena, resultado);
            // Almacena la contraseña en el array de contraseñas
            snprintf(contrasenas[contador], sizeof(contrasenas[contador]), "%s", cadena);

            // Incrementa el contador y la cadena para la siguiente iteración
            contador++;
            for (int i = 3; i >= 0; i--) {
                if (cadena[i] == 'z') {
                    cadena[i] = 'a';
                } else {
                    cadena[i]++;
                    break;
                }
            }
        }
    } else {
        // Proceso padre: generando combinaciones de "naaa" a "zzz"
        cadena[0] = 'n';  // Comenzar desde 'n'
        while (cadena[0] <= 'z') {
            calcularMD5(cadena, resultado);
            // Almacena la contraseña en el array de contraseñas
            snprintf(contrasenas[contador], sizeof(contrasenas[contador]), "%s", cadena);

            // Incrementa el contador y la cadena para la siguiente iteración
            contador++;
            for (int i = 3; i >= 0; i--) {
                if (cadena[i] == 'z') {
                    cadena[i] = 'a';
                } else {
                    cadena[i]++;
                    break;
                }
            }
        }

        // Espera a que el proceso hijo termine
        wait(NULL);

        // Imprime las contraseñas generadas
        printf("Contraseñas generadas:\n");
        for (int i = 0; i < contador; i++) {
            printf("%s\n", contrasenas[i]);
        }
    }

    return 0;
}
