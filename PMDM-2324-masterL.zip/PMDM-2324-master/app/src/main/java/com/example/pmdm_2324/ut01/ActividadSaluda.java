package com.example.pmdm_2324.ut01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.pmdm_2324.R;

public class ActividadSaluda extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ut01_actividad_saluda);
    }
}