package com.example.pmdm_2324.ut04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.pmdm_2324.R;

public class u4a1BuenaPersona extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.u4a1_buena_persona);
    }
}