/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.psp2324;

/**
 *
 * @author Javier
 */
public class PSP2324 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
