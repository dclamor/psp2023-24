#!/bin/python3

print("hola mundo")
