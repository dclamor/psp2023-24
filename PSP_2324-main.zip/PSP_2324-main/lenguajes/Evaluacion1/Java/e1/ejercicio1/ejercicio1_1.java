package Java.e1.ejercicio1;

public class ejercicio1_1 {
    public static void main(String[] args) {
        holamundo1_1 holamundo = new holamundo1_1();
        holamundo.start();
    }
}
