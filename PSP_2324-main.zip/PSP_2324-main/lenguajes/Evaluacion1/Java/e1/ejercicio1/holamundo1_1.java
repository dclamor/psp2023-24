package Java.e1.ejercicio1;

public class holamundo1_1 extends Thread {

    @Override
    public void start() {
        System.out.println("Hola mundo");
    }

}
