package Java.e1.ejercicio1;

public class holamundo1_2 implements Runnable {

    @Override
    public void run() {
        System.out.println("Con un metodo RUN");
    }

}
