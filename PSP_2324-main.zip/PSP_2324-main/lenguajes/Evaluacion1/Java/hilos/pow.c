#include<stdio.h>
int main(int argc, char const *argv[])
{
    int n;
    scanf("%d",&n);
    printf("%d\n",n*n);
    return 0;
}
